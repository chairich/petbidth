

import React from 'react';

const Divider = () => {
  return  <div className="divider"></div>
};

export default Divider;