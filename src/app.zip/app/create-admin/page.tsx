export default function CreateAdminPage() {
  return (
    <div>
      <h1>Create Admin Page</h1>
      <p>หน้านี้ยังไม่พร้อมใช้งาน</p>
    </div>
  );
}
