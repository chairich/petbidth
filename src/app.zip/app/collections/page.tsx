import React from "react";
import Collections from "@/components/collections";

export const metadata = {
	title: "Funto Collections - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<Collections />
		</>
	);
};

export default index;
