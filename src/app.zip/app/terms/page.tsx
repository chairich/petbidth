import React from "react";
import Terms from "@/components/terms";

export const metadata = {
	title: "Funto Terms - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<Terms />
		</>
	);
};

export default index;
