import CreateBannerForm from "@/components/creat-banner";
import React from "react";

export const metadata = {
	title: "หน้าประมุล - เว็บประมูล เพ็ชบิดไทย",
};

const index = () => {
	return (
		<>
			<CreateBannerForm />
		</>
	);
};

export default index;
