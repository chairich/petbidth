import EditAuction from '@/components/edit-auction'
import React from "react";

export const metadata = {
	title: "โพสกระทู้ประมูล - เว็บประมูล เพ็ชบิดไทย",
};

const index = () => {
	return (
		<>
			<EditAuction />
		</>
	);
};

export default index;
