import ShowShopArea from "@/components/show-shop-vip";
import React from "react";

export const metadata = {
	title: "ร้านค้าวีไอพี - เว็บประมูล เพ็ชบิดไทย",
};

const index = () => {
	return (
		<>
			<ShowShopArea />
		</>
	);
};

export default index;
