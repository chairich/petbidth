import HelpCenter from "@/components/help-center";
import React from "react";

export const metadata = {
	title: "Funto Help Center - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<HelpCenter />
		</>
	);
};

export default index;
