export default function Page() {
  return <div>Settings page under construction</div>;
}
