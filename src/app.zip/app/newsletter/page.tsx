import React from "react";
import Newsletter from "@/components/newsletter";

export const metadata = {
	title: "Funto Newsletter - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<Newsletter />
		</>
	);
};

export default index;
