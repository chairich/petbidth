import Livebids from "@/components/dashboard/live-bids";
import React from "react";

export const metadata = {
	title: "Funto Livebids - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<Livebids />
		</>
	);
};

export default index;
