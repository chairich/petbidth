import NewsFormArea from "@/components/news";
import React from "react";

export const metadata = {
	title: "หน้าข่าวสาร - เว็บประมูล เพ็ชบิดไทย",
};

const index = () => {
	return (
		<>
			<NewsFormArea />
		</>
	);
};

export default index;
