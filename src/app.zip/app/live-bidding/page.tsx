import LiveBidding from "@/components/live-bidding";
import React from "react";

export const metadata = {
	title: "ประมูลทั้งหมด - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<LiveBidding />
		</>
	);
};

export default index;
