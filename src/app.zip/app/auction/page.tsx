import Auction from "@/components/auction";
import React from "react";

export const metadata = {
	title: "หน้าประมุล - เว็บประมูล เพ็ชบิดไทย",
};

const index = () => {
	return (
		<>
			<Auction />
		</>
	);
};

export default index;
