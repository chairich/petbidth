
'use client'
import React from 'react';

export default function GeneralDashboard() {
  return (
    <div className="container py-5">
      <h1>ยินดีต้อนรับ, ผู้ใช้ทั่วไป</h1>
      <p>นี่คือแดชบอร์ดสำหรับผู้ใช้งานทั่วไป</p>
      {/* ใส่คอนเทนต์อื่น ๆ ได้ตามต้องการ */}
    </div>
  );
}
