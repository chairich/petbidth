import React from "react";
import About from "@/components/about";

export const metadata = {
	title: "Funto About - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<About />
		</>
	);
};

export default index;
