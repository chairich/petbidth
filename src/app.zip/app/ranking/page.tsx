import Ranking from "@/components/ranking";
import React from "react";

export const metadata = {
	title: "Funto Ranking - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<Ranking />
		</>
	);
};

export default index;
