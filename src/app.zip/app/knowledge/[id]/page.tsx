import { createClient } from '@/lib/supabase/server';
import CommentForm from '@/components/CommentForm';

export default async function KnowledgeDetailPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: post } = await supabase.from('knowledge_posts').select('*').eq('id', params.id).single();
  const { data: comments } = await supabase.from('knowledge_comments').select('*, user:users(*)').eq('post_id', params.id).order('created_at');

  return (
    <div className="p-4 max-w-3xl mx-auto text-white">
      <h1 className="text-2xl font-bold mb-2">{post.title}</h1>
      <p className="text-sm text-gray-400 mb-4">{post.category}</p>
      <div className="space-y-2 mb-4">
        {post.image_urls?.map((url: string, i: number) => <img key={i} src={url} alt="" className="rounded" />)}
      </div>
      <p className="mb-8 whitespace-pre-wrap">{post.content}</p>
      <h2 className="text-xl font-semibold mb-2">ความคิดเห็น</h2>
      <CommentForm postId={params.id} />
      <div className="space-y-2 mt-4">
        {comments?.map((c, i) => (
          <div key={i} className="bg-zinc-800 p-2 rounded">
            <strong>{c.user?.username || 'ไม่ระบุชื่อ'}</strong>
            <p>{c.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
