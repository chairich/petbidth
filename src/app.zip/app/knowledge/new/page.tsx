'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';

export default function NewKnowledgePost() {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [content, setContent] = useState('');
  const [images, setImages] = useState<FileList | null>(null);
  const supabase = createClientComponentClient();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return alert('กรุณาเข้าสู่ระบบ');

    const uploads: string[] = [];
    if (images) {
      for (let i = 0; i < images.length; i++) {
        const file = images[i];
        const filename = `${Date.now()}_${i}`;
        await supabase.storage.from('knowledge-images').upload(filename, file);
        const { data } = supabase.storage.from('knowledge-images').getPublicUrl(filename);
        uploads.push(data.publicUrl);
      }
    }

    await supabase.from('knowledge_posts').insert([{
      title,
      category,
      content,
      image_urls: uploads,
      user_id: user.id,
    }]);

    router.push('/knowledge');
  };

  return (
    <div className="p-4 max-w-2xl mx-auto text-white">
      <h1 className="text-xl font-bold mb-4">เพิ่มบทความ</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="หัวข้อ" className="w-full p-2 bg-zinc-800 rounded" />
        <input type="text" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="หมวดหมู่ / หมวดย่อย" className="w-full p-2 bg-zinc-800 rounded" />
        <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="เนื้อหา" rows={8} className="w-full p-2 bg-zinc-800 rounded"></textarea>
        <input type="file" accept="image/*" multiple onChange={(e) => setImages(e.target.files)} className="text-white" />
        <button type="submit" className="px-4 py-2 bg-blue-500 rounded">โพสต์</button>
      </form>
    </div>
  );
}
