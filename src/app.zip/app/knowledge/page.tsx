'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';

export default function KnowledgePage() {
  const [articles, setArticles] = useState<any[]>([]);
  const supabase = createClientComponentClient();

  useEffect(() => {
    const fetchArticles = async () => {
      const { data } = await supabase.from('knowledge_posts').select('*').order('created_at', { ascending: false });
      setArticles(data || []);
    };
    fetchArticles();
  }, []);

  return (
    <div className="p-4 max-w-4xl mx-auto text-white">
      <h1 className="text-2xl font-bold mb-4">บทความให้ความรู้</h1>
      <Link href="/knowledge/new" className="text-blue-400 underline">➕ เขียนบทความใหม่</Link>
      <div className="grid grid-cols-1 gap-4 mt-4">
        {articles.map((post) => (
          <Link key={post.id} href={`/knowledge/${post.id}`} className="border p-4 rounded bg-black hover:bg-zinc-900">
            <h2 className="text-xl font-semibold">{post.title}</h2>
            <p className="text-sm text-gray-400">{post.category}</p>
            <p className="mt-2">{post.content?.slice(0, 100)}...</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
