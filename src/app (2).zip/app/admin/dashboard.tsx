// src/app/news/post/page.tsx

export default function PostPage() {
  return (
    <main className="p-6">
      <h1>ข่าวใหม่</h1>
      <p>หน้านี้เพิ่มไว้เพื่อให้ Next.js รู้จักเป็นโมดูล</p>
    </main>
  );
}
