import CreateAuction from "@/components/post-auction";
import React from "react";

export const metadata = {
	title: "โพสกระทู้ประมูล - เว็บประมูล เพ็ชบิดไทย",
};

const index = () => {
	return (
		<>
			<CreateAuction />
		</>
	);
};

export default index;
