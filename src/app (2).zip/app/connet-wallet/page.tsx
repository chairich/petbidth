import ConnetWallet from "@/components/connet-wallet";
import React from "react";

export const metadata = {
	title: "Funto Connet Wallet - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<ConnetWallet />
		</>
	);
};

export default index;
