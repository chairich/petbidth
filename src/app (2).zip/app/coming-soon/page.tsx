

import ComingSoon from '@/components/coming-soon';
import React from 'react';

export const metadata = {
	title: "Funto Coming Soon - PetBidThai.com",
};



const index = () => {
  return (
    <>
      <ComingSoon />
    </>
  );
};

export default index;