import ItemDetails from "@/components/item-details";
import React from "react";

export const metadata = {
	title: "Funto Item Details - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<ItemDetails />
		</>
	);
};

export default index;
