import ForgetPassword from "@/components/forget-password";
import React from "react";

export const metadata = {
	title: "Funto Forget Password - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<ForgetPassword />
		</>
	);
};

export default index;
