import Privacy from "@/components/privacy";
import React from "react";

export const metadata = {
	title: "Funto Privacy - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<Privacy />
		</>
	);
};

export default index;
