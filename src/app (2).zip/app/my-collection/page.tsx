import React from "react";
import MyCollection from "@/components/dashboard/my-collection";

export const metadata = {
	title: "Funto My Collection - PetBidThai.com",
};

const index = () => {
	return (
		<>
			<MyCollection />
		</>
	);
};

export default index;
