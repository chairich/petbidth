import Error from "@/components/error";

export const metadata = {
	title: "404 error || เว - PetBidThai.com",
};
const index = () => {
	return (
		<>
			<Error />
		</>
	);
};

export default index;
