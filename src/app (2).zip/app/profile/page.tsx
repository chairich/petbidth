import EditProfileArea from "@/components/edit-profile";
import React from "react";

export const metadata = {
	title: "หน้าประมุล - เว็บประมูล เพ็ชบิดไทย",
};

const index = () => {
	return (
		<>
			<EditProfileArea />
		</>
	);
};

export default index;
