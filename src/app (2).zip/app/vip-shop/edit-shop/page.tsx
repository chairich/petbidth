// app/vip-shop/edit-shop/page.tsx

'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import HeaderOne from '@/layouts/headers/HeaderOne';
import FooterOne from '@/layouts/footers/FooterOne';
import Breadcrumb from '@/components/common/Breadcrumb';
import Divider from '@/components/common/Divider';

type Shop = {
  id: string;
  shop_name: string;
  description?: string;
};

export default function EditShopListPage() {
  const [shops, setShops] = useState<Shop[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const fetchShops = async () => {
      const { data, error } = await supabase
        .from('banners')
        .select('id, shop_name, description');

      if (data) {
        setShops(data);
      } else {
        console.error('เกิดข้อผิดพลาดในการโหลดข้อมูลร้านค้า:', error);
      }
      setLoading(false);
    };

    fetchShops();
  }, []);

  return (
    <>
      <HeaderOne />
      <Breadcrumb title="เลือกร้านค้าเพื่อแก้ไข" />
      <Divider />

      <div className="container py-8 text-white">
        <h2 className="text-2xl font-bold mb-4">เลือกร้านค้า</h2>

        {loading ? (
          <p>กำลังโหลด...</p>
        ) : shops.length === 0 ? (
          <p>ไม่พบข้อมูลร้านค้า</p>
        ) : (
          <ul className="space-y-4">
            {shops.map((shop) => (
              <li
                key={shop.id}
                className="bg-gray-800 p-4 rounded shadow flex items-center justify-between"
              >
                <div>
                  <p className="text-lg font-semibold">{shop.shop_name}</p>
                  {shop.description && (
                    <p className="text-sm text-gray-300">{shop.description}</p>
                  )}
                </div>
                <button
                  onClick={() => router.push(`/vip-shop/edit-shop/${shop.id}`)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
                >
                  แก้ไข
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <FooterOne />
    </>
  );
}
