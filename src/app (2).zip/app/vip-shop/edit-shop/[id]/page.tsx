'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import EditForm from './EditForm';
import { supabase } from '@/lib/supabaseClient';

export default function EditShopPage() {
  const { id } = useParams();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchShop = async () => {
      if (!id) return;
      const { data, error } = await supabase.from('banners').select('*').eq('id', id).single();
      if (data) {
        setData(data);
      } else {
        console.error('ไม่พบข้อมูลร้านค้า', error);
      }
      setLoading(false);
    };

    fetchShop();
  }, [id]);

  if (loading) return <p className="text-center text-white p-10">กำลังโหลดข้อมูล...</p>;
  if (!data) return <p className="text-center text-red-500 p-10">ไม่พบข้อมูลร้านค้า</p>;

  return <EditForm data={data} />;
}
