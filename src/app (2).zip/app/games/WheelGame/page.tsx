// app/games/WheelGame/page.tsx
'use client';

import WheelGame from '@/components/games/WheelGame';

export default function WheelGamePage() {
  return <WheelGame />;
}
