'use client';

import React from "react";
import HeorAreaHomeOne from "./HeorAreaHomeOne";
import FeaturedHomeOne from "./FeaturedHomeOne";
import TopSellerHomeOne from "./TopSellerHomeOne";
import HeaderOne from "@/layouts/headers/HeaderOne";
import LiveAuctionHomeOne from "./LiveAuctionHomeOne";
import Divider from "@/components/common/Divider";
import DiscoverHomeOne from "./DiscoverHomeOne";
import PopularCollectionHomeOne from "./PopularCollectionHomeOne";
import ProcessHomeOne from "./ProcessHomeOne";
import CollectionHomeOne from "./CollectionHomeOne";
import FooterOne from "@/layouts/footers/FooterOne";
import ScrollToTop from "@/components/common/ScrollToTop";


const HomeOne = () => {
	if (typeof window !== "undefined") {
		require("bootstrap/dist/js/bootstrap");
	}
	return (
		<>
			<ScrollToTop />
			<HeaderOne />
			<HeorAreaHomeOne />
			<Divider />
			<LiveAuctionHomeOne />
			<Divider />
			<TopSellerHomeOne />
			<Divider />
			<ProcessHomeOne />
			<Divider />
			<CollectionHomeOne />
			<Divider />
			<FooterOne />
		</>
	);
};

export default HomeOne;
